#Enteringfat grams consumed in a day
print('Nutritionist\n')
calories = float(input('Enter the number of fats consumed:'))
numberOfCalories = (calories * 9);


#calories from cabohydrates
calocarbohydrates = (numberOfCalories * 4)

print(numberOfCalories)
print(calocarbohydrates)