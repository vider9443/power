#Serendipity Booksellers
print('Hello customer, Welcome to Serendipity Book Club \n')

#book club
numberOfBooks = int(input('Enter the number of books purchased this month: '))

#points awarding
if numberOfBooks <= 0:
    print('Points awarded is: 0');
elif numberOfBooks <= 1:
    print('Points awarded is: 6');
elif numberOfBooks <= 2:
    print('Points awarded is: 16');
elif numberOfBooks <= 3:
    print('Points awarded is: 32');
else:
    print('Points awarded is: 60');
