
# library that we use in order to choose
# on random career from a list of careers

print('These are the available careers \n')
career = [' Engineer', 'Electrician', 'Programmer', 'Doctor',
		'Nurse', 'Teacher', 'Pilot', 'Driver' ]

careerAdvice = [' Engineer - This is a great career.\n Ensure you are strong at sciences', 'Electrician - Bravo, Light the world.\n Prepare for Electronic units', 'Programmer - Tada! These are some of the langauages \n Python, Java, C, C#', 'Doctor - These are the options\n Surgeon, Gynacologist etc',
		'Nurse - Here you take care of the patients', 'Teacher - Help, bring keys of success to the world \n specialise in Lecturer, primary or high school', 'Pilot - Ayo, better get serious in that geography class', 'Driver _ WRC safary rally is waiting for you' ]

careerQuestions = ['1.What subjects do i need?' , '2. Which area can be my specialty?', 'Whats the average salary?']

#The available careers are printed
print(career)

name = input("\n What is your preffered career?\n ")
# Here the user is asked to choose the preffered career first

print("Good Luck ! ", name)

for item in career:
    if item == "Engineer":
      print(careerAdvice[0])
    elif item == "Electrician":
      print(careerAdvice[1])
    elif item == "Programmer":
      print(careerAdvice[3])
    elif item == "Nurse":
      print(careerAdvice[4])
    elif item == "Teacher":
      print(careerAdvice[5])
    elif item == "Pilot":
      print(careerAdvice[6])
    elif item == "Driver":
      print(careerAdvice[7])
    else:
      print('Not Available')